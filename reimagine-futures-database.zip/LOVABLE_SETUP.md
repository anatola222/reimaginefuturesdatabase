# Lovable setup prompt

Paste this into Lovable after the code has synced from GitHub.

---

This project is a React + Vite app called Reimagined Futures. Keep the existing design, fonts, layout and copy exactly as they are. Only add a backend using Lovable Cloud.

Create these tables:

1. **visions**: id, created_at, values (text array, up to 3 value ids), place (text), year (text, optional), description (text), status (text: "pending" | "approved" | "hidden", default "pending").
2. **lab_requests**: id, created_at, name, organization, email, group_size, note.
3. **value_approvals**: id, vision_id, value_id, approved (boolean). This is for AI-inferred values a curator approves.

Security (row level security):
- Anyone can INSERT into visions and lab_requests. They cannot read, edit or delete them.
- Anyone can SELECT visions where status = "approved".
- Only the admin (me, signed in) can SELECT, UPDATE and DELETE everything in all three tables.
- Add email sign-in for the admin only. No public accounts.

Wire up the app:
- In `src/components/Gather.tsx`, the `AddVision` form currently saves to localStorage with `save("rfd:submissions", …)`. Insert into `visions` instead, with status "pending". Keep the same thank-you screen.
- In the same file, the `Host` (Lab) form saves with `save("rfd:requests", …)`. Insert into `lab_requests` instead. Change the thank-you text to: "Thank you. We'll be in touch soon." Email me when a new request arrives.
- In `src/components/Pages.tsx`, the `Curate` page should require admin sign-in. Show pending visions from `visions` with Approve and Hide buttons. Keep the existing approve/pending chips for inferred values, saving them to `value_approvals`.
- Approved visions from `visions` should appear in the Archive alongside the existing ones in `src/data/visions.ts` and count toward the value totals.
- Leave the mood board in browser storage. It is personal to each visitor.

Do not add sample data, tracking, or analytics.
