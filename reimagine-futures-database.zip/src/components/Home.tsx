import { useEffect, useMemo, useState } from "react";
import { PILLARS, pillarById, type PillarId } from "../data/pillars";
import { VALUES, valueById } from "../data/values";
import { WORLDS, thumbOf } from "../data/worlds";
import { useStore } from "../lib/store";
import { coOccurrence, valueCounts, visible, type CohortFilter } from "../lib/stats";
import { DreamStrip, Label, Segmented, ValueChip } from "./ui";

type Pt = [number, number];
const C: Pt = [50, 47];
const CP: Pt = [50, 42];
/** Tiles on two rings around the cube. Inner ring links to the core; outer ring links to its nearest inner tile. */
function ringLayout(n: number, portrait: boolean) {
  const innerN = Math.min(n, portrait ? 8 : 10);
  const outerN = n - innerN;
  const c = portrait ? CP : C;
  const ring = (count: number, rx: number, ry: number, off: number): Pt[] =>
    Array.from({ length: count }, (_, i) => {
      const a = off + (i / count) * Math.PI * 2;
      return [c[0] + Math.cos(a) * rx, c[1] + Math.sin(a) * ry];
    });
  const inner = portrait ? ring(innerN, 33, 22, -Math.PI / 2) : ring(innerN, 27, 33, -Math.PI / 2);
  const outer = portrait ? ring(outerN, 44, 36, -Math.PI / 2 + 0.2) : ring(outerN, 45, 44, -Math.PI / 2 + 0.15);
  const parent = outer.map((p) => {
    let best = 0, d = 1e9;
    inner.forEach((q, j) => { const dd = (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2; if (dd < d) { d = dd; best = j; } });
    return best;
  });
  return { inner, outer, parent, c };
}

function usePortrait() {
  const q = "(orientation: portrait), (max-width: 700px)";
  const [p, setP] = useState(() => matchMedia(q).matches);
  useEffect(() => {
    const m = matchMedia(q);
    const on = () => setP(m.matches);
    m.addEventListener("change", on);
    return () => m.removeEventListener("change", on);
  }, []);
  return p;
}

function Network() {
  const { go } = useStore();
  const portrait = usePortrait();
  const [featured, setFeatured] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => setFeatured((f) => (f + 1) % WORLDS.length), 6000);
    return () => clearInterval(t);
  }, [paused]);

  const others = WORLDS.filter((_, i) => i !== featured);
  const f = WORLDS[featured];
  const { inner, outer, parent, c: C } = useMemo(() => ringLayout(others.length, portrait), [others.length, portrait]);
  const mid = (p: Pt, q: Pt, k = 0.5): Pt => [p[0] + (q[0] - p[0]) * k, p[1] + (q[1] - p[1]) * k];
  const nodes: Pt[] = [...inner.map((p) => mid(p, C, 0.32)), ...outer.map((p, i) => mid(p, inner[parent[i]], 0.45))];

  return (
    <section className={`stage${portrait ? " portrait" : ""}`} aria-label="Worlds network"
      onPointerEnter={() => setPaused(true)} onPointerLeave={() => setPaused(false)}>
      <div className="floor" aria-hidden="true"><div className="floor-grid" /></div>

      <svg className="net" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        {inner.map((p, i) => <line key={`i${i}`} x1={C[0]} y1={C[1]} x2={p[0]} y2={p[1]} className="ln" />)}
        {inner.map((p, i) => { const q = inner[(i + 1) % inner.length]; return <line key={`r${i}`} x1={p[0]} y1={p[1]} x2={q[0]} y2={q[1]} className="ln faint" />; })}
        {outer.map((p, i) => { const q = inner[parent[i]]; return <line key={`o${i}`} x1={q[0]} y1={q[1]} x2={p[0]} y2={p[1]} className="ln faint" />; })}
      </svg>

      {nodes.map((n, i) => <span key={`n${i}`} className="node" style={{ left: `${n[0]}%`, top: `${n[1]}%`, animationDelay: `${(i % 7) * 0.5}s` }} aria-hidden="true" />)}

      {others.map((w, i) => {
        const isInner = i < inner.length;
        const p = isInner ? inner[i] : outer[i - inner.length];
        return (
          <button key={w.id} className={`tile${isInner ? "" : " far"}`} style={{ left: `${p[0]}%`, top: `${p[1]}%` }}
            onClick={() => setFeatured(WORLDS.indexOf(w))} aria-label={`Feature ${w.title}`} title={w.title}>
            <img src={thumbOf(w)} alt="" loading="lazy" decoding="async" width={240} height={240} />
          </button>
        );
      })}

      <div className="cube" style={{ left: `${C[0]}%`, top: `${C[1]}%` }}>
        <svg className="hex" viewBox="0 0 100 100" aria-hidden="true">
          <polygon points="50,2 94,26 94,74 50,98 6,74 6,26" />
        </svg>
        <button className="cube-face" onClick={() => go({ page: "world", id: f.id })} aria-label={`Enter ${f.title}`}>
          <img key={f.id} src={f.image} alt={f.title} decoding="async" width={820} height={820} />
        </button>
      </div>

      <div className="stage-cap">
        <Label>Featured world · {f.origin}</Label>
        <button className="cap-title" onClick={() => go({ page: "world", id: f.id })}>{f.title} →</button>
      </div>
    </section>
  );
}

export default function Home() {
  const { go, cohort, setCohort, approved } = useStore();
  const [focus, setFocus] = useState<PillarId | null>(null);
  const counts = useMemo(() => valueCounts(cohort, approved), [cohort, approved]);
  const pairs = useMemo(() => {
    // Strongest pairs first, each value used at most once.
    const used = new Set<string>(), out: [string, number][] = [];
    for (const [k, n] of [...coOccurrence(cohort, approved)].sort((a, b) => b[1] - a[1])) {
      const [x, y] = k.split("|");
      if (used.has(x) || used.has(y)) continue;
      used.add(x); used.add(y); out.push([k, n]);
      if (out.length === 5) break;
    }
    return out;
  }, [cohort, approved]);
  const max = Math.max(1, ...Object.values(counts));

  return (
    <>
      <header className="hero wrap">
        <h1>Hey, Dreamkeeper.</h1>
        <p className="lede">A living database of hopeful futures, imagined by people ages 7 to 89 across five continents. Some are a decade away. Some are seven generations out.</p>
        <div className="hero-ctas"><button className="cta" onClick={() => go({ page: "add" })}>Add your vision</button><button className="cta ghost" onClick={() => go({ page: "host" })}>Join the Lab</button></div>
      </header>

      <Network />

      <section className="wrap section">
        <h2>What do you want the future to hold?</h2>
        <p className="lede small">Tap a value to see who dreamed it and the worlds that hold it.</p>

        <div className="controls">
          <div>
            <Label>Who dreamed it</Label>
            <Segmented label="Cohort" value={cohort} onChange={(v) => setCohort(v as CohortFilter)}
              options={[{ v: "all", l: "Everyone" }, { v: "youth", l: "Youth" }, { v: "adult", l: "Adults" }, { v: "mixed", l: "Mixed ages" }].filter((o) => o.v === "all" || visible().some((x) => x.cohort === o.v))} />
          </div>
        </div>

        <DreamStrip size="lg" active={focus ? [focus] : undefined} onPick={(p) => setFocus(focus === p ? null : p)} />
        {focus && <p className="pillar-line"><b>{pillarById(focus).name}.</b> {pillarById(focus).description}</p>}

        <div className="pillars">
          {PILLARS.map((p) => (
            <div key={p.id} className={`pcol${focus && focus !== p.id ? " dim" : ""}`}>
              <Label>{p.id === "S" ? "✦" : p.id} — {p.short}</Label>
              <ul>
                {VALUES.filter((v) => v.pillar === p.id).map((v) => (
                  <li key={v.id}>
                    <button className="star" onClick={() => go({ page: "value", id: v.id })}>
                      <span className="star-dot" style={{ ["--s" as string]: `${6 + (counts[v.id] / max) * 14}px`, opacity: counts[v.id] ? 1 : 0.3 }} />
                      <span className="star-name">{v.name}</span>
                      <span className="star-n">{counts[v.id]}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="together">
          <Label>Dreamed together most often</Label>
          <ul>
            {pairs.map(([k, n]) => {
              const [a, b] = k.split("|");
              return (
                <li key={k}>
                  <ValueChip id={a} /> <span className="plus">+</span> <ValueChip id={b} />
                  <span className="pair-n">{n} {n === 1 ? "person" : "people"}</span>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      <section className="wrap section worlds-grid-sec">
        <h2>Featured worlds</h2>
        <div className="worlds-grid">
          {WORLDS.map((w) => (
            <button key={w.id} className="wcard" onClick={() => go({ page: "world", id: w.id })}>
              <img src={thumbOf(w)} alt="" loading="lazy" decoding="async" width={320} height={320} />
              <span className="wcard-t">{w.title}</span>
              <span className="wcard-v">{w.values.slice(0, 3).map((v) => valueById(v.id)?.name).join(" · ")}</span>
            </button>
          ))}
        </div>
      </section>
    </>
  );
}
