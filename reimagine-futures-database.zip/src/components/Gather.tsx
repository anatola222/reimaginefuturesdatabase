import { useMemo, useState, type FormEvent } from "react";
import { PILLARS } from "../data/pillars";
import { VALUES, valueById } from "../data/values";
import { WORLDS, thumbOf } from "../data/worlds";
import { useStore } from "../lib/store";
import { valueCounts } from "../lib/stats";
import { DreamStrip, Label, ValueChip } from "./ui";

// In this preview, submissions stay in the visitor's browser. On Lovable, send them to the
// database (Supabase) with status "pending" so they land in the curator queue.
const save = (k: string, v: unknown) => {
  try { const a = JSON.parse(localStorage.getItem(k) ?? "[]"); a.push(v); localStorage.setItem(k, JSON.stringify(a)); } catch { /* storage unavailable */ }
};

const PLACES = ["Sky Islands", "Underwater City", "Parallel Dimension", "Vast Desert", "Bioluminescent Forest", "A city I know", "Somewhere else"];

export function AddVision() {
  const { go, approved } = useStore();
  const [vals, setVals] = useState<string[]>([]);
  const [place, setPlace] = useState("");
  const [year, setYear] = useState("");
  const [text, setText] = useState("");
  const [age, setAge] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState("");
  const counts = useMemo(() => valueCounts("all", approved), [approved]);

  const toggle = (id: string) => setVals((v) => (v.includes(id) ? v.filter((x) => x !== id) : v.length < 3 ? [...v, id] : v));
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!vals.length) return setErr("Choose at least one value.");
    if (text.trim().length < 10) return setErr("Tell us a little more about what visitors see.");
    if (!age) return setErr("Please confirm you are 13 or older.");
    setErr("");
    save("rfd:submissions", { vals, place, year, text: text.trim(), at: new Date().toISOString(), status: "pending" });
    setDone(true);
    window.scrollTo({ top: 0 });
  };

  if (done) {
    const worlds = WORLDS.filter((w) => w.values.some((v) => vals.includes(v.id))).slice(0, 4);
    return (
      <div className="wrap section page">
        <Label>Your vision is in</Label>
        <h1>You're part of the constellation.</h1>
        <div className="chips glow">{vals.map((id) => <ValueChip key={id} id={id} />)}</div>
        <ul className="kin-list">
          {vals.map((id) => (
            <li key={id}><b>{counts[id] ?? 0}</b> others dreamed {valueById(id)?.name}.</li>
          ))}
        </ul>
        {worlds.length > 0 && (
          <section className="block">
            <h2>Worlds that hold what you hold</h2>
            <div className="wrow">
              {worlds.map((w) => (
                <button key={w.id} className="wmini" onClick={() => go({ page: "world", id: w.id })}>
                  <img src={thumbOf(w)} alt="" loading="lazy" width={240} height={240} /><span className="wmini-t">{w.title}</span>
                </button>
              ))}
            </div>
          </section>
        )}
        <p className="note">Visions are reviewed before they appear in the archive. This preview keeps your vision in your browser only.</p>
        <div className="bridge">
          <h2>Now imagine it with your whole community.</h2>
          <p className="lede">The D.R.E.A.M. Futures Lab brings this to you and your community. Every paid Lab sponsors a youth cohort.</p>
          <button className="cta" onClick={() => go({ page: "host" })}>Explore the Lab</button>
        </div>
      </div>
    );
  }

  return (
    <form className="wrap section page addform" onSubmit={submit} noValidate>
      <Label>Add your vision</Label>
      <h1>What future do you want?</h1>
      <p className="lede">Four questions, about two minutes. Your vision joins hundreds of others from around the world.</p>

      <fieldset>
        <legend><h2>1. What values rule your future world?</h2><span className="muted small">Choose up to three.</span></legend>
        <div className="pick-cols">
          {PILLARS.map((p) => (
            <div key={p.id} className="pick-col">
              <Label>{p.id === "S" ? "✦" : p.id} — {p.short}</Label>
              {VALUES.filter((v) => v.pillar === p.id).map((v) => (
                <button type="button" key={v.id} className={`pick${vals.includes(v.id) ? " on" : ""}`} aria-pressed={vals.includes(v.id)}
                  onClick={() => toggle(v.id)} disabled={!vals.includes(v.id) && vals.length >= 3}>
                  {v.name}
                </button>
              ))}
            </div>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend><h2>2. Where does your world take place?</h2></legend>
        <div className="chips">
          {PLACES.map((p) => (
            <button type="button" key={p} className={`pick${place === p ? " on" : ""}`} aria-pressed={place === p} onClick={() => setPlace(place === p ? "" : p)}>{p}</button>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend><h2>3. A spaceship lands on your new world. What will visitors see?</h2><span className="muted small">The buildings, the people, the land. Be specific.</span></legend>
        <textarea id="vision-text" rows={5} value={text} onChange={(e) => setText(e.target.value)} placeholder="As they land, they see…" maxLength={1200} />
      </fieldset>

      <fieldset>
        <legend><h2>4. What year is it?</h2><span className="muted small">Optional.</span></legend>
        <input id="vision-year" inputMode="numeric" value={year} onChange={(e) => setYear(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="2200" />
      </fieldset>

      <label className="check" htmlFor="age-ok">
        <input id="age-ok" type="checkbox" checked={age} onChange={(e) => setAge(e.target.checked)} />
        <span>I am 13 or older. I understand my vision may be shared anonymously in the database.</span>
      </label>
      {err && <p className="err" role="alert">{err}</p>}
      <button className="cta" type="submit">Add my vision</button>
    </form>
  );
}

const METHOD: [string, string][] = [
  ["Remember", "Surface your community's untapped wisdom, the stories and strengths that got you here."],
  ["Reinvision", "Build a five-senses vision of the future you actually want."],
  ["Retrace", "Work backward from that vision to a real roadmap with steps."],
  ["Reclaim", "Every person claims what they will own starting Monday."],
  ["Reembody", "Prototype it. Leave the room with something real, not a slide deck."],
];
const OUTCOMES = [
  "A shared, tangible vision of your group's future",
  "A backcast roadmap with owned next steps",
  "A working prototype or pilot concept",
  "People who have practiced imagination as an everyday skill",
];
const EMAIL = "anatola@anatolaaraba.com";

const EXPERIENCE: [string, string][] = [
  ["Futures imagination", "A guided visualization into emerging possibilities and alternative timelines."],
  ["Visual prototyping", "Turn your future into a tangible visual artifact with generative tools."],
  ["Community", "Share visions and learn from fellow creators, neighbors and colleagues."],
];

export function Host() {
  const [sent, setSent] = useState(false);
  const [copied, setCopied] = useState(false);
  const [form, setForm] = useState({ name: "", org: "", email: "", size: "", note: "" });
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });
  const submit = (e: FormEvent) => { e.preventDefault(); save("rfd:requests", { ...form, at: new Date().toISOString() }); setSent(true); };
  const copy = () => navigator.clipboard?.writeText(EMAIL).then(() => setCopied(true), () => setCopied(false));

  return (
    <div className="page host">
      <div className="wrap section host-hero">
        <DreamStrip size="lg" active={["D", "R", "E", "A", "M"]} />
        <h1>D.R.E.A.M. Futures Lab</h1>
        <p className="lede">Imagine, prototype, and shape the futures you want to see. For you and your community.</p>
        <div className="arc" aria-label="Uncertainty, Imagination, Agency, Action">
          {["Uncertainty", "Imagination", "Agency", "Action"].map((x, i) => (
            <span key={x} className="arc-step"><i aria-hidden="true" />{x}{i < 3 && <b aria-hidden="true">→</b>}</span>
          ))}
        </div>
      </div>

      <div className="wrap section split2">
        <div><h2>We cannot build a future we cannot first imagine.</h2></div>
        <div className="prose-col">
          <p>Right now, our vision of tomorrow is trapped between clinical tech optimization and climate anxiety. The Lab is a studio for breaking that paralysis.</p>
          <p>Grounded in the five pillars of D.R.E.A.M., you'll spend less time talking about the future and more time making it visible, and leave with an artifact of your world to bring back into your projects, community and leadership.</p>
        </div>
      </div>

      <div className="wrap section">
        <Label>What you'll experience</Label>
        <div className="formats">
          {EXPERIENCE.map(([h, b]) => <div key={h}><h3>{h}</h3><p>{b}</p></div>)}
        </div>
      </div>

      <div className="wrap section">
        <Label>The method · 5 Re</Label>
        <h2>Uncertainty → Imagination → Agency → Action</h2>
        <ol className="method">
          {METHOD.map(([h, b], i) => (
            <li key={h}><span className="method-n">{i}</span><h3>{h}</h3><p>{b}</p></li>
          ))}
        </ol>
      </div>

      <div className="wrap section">
        <Label>Two ways in</Label>
        <div className="ways">
          <div className="way">
            <h3>Join a live Lab</h3>
            <p>Free and online, open to anyone ready to imagine. Add your vision now and we'll keep you posted on the next date.</p>
            <AddLink />
          </div>
          <div className="way">
            <h3>Bring the Lab to your people</h3>
            <p>On-site for teams, schools and communities of up to 60. Half-day, with full-day available.</p>
            <ul className="outcomes">{OUTCOMES.map((o) => <li key={o}>{o}</li>)}</ul>
          </div>
        </div>
      </div>

      <div className="wrap section">
        <div className="give">
          <span className="give-mark" aria-hidden="true" />
          <div>
            <Label>The bridge</Label>
            <p><b>Every paid Lab sponsors a youth cohort through the same curriculum.</b> Battle-tested with young people in Ghana and justice-impacted youth in the US, not designed in a slide deck.</p>
          </div>
        </div>
      </div>

      <div className="wrap section split2">
        <div><Label>Led by</Label><h2>Anatola Araba</h2></div>
        <div className="prose-col">
          <p>Anatola Araba is an ancient futurist and Forbes 30 Under 30 founder of R3imagine. She directed Afro Algorithms, the first sci-fi short film on the moon, spoke at UNGA 81, and teaches at NYU Tisch.</p>
        </div>
      </div>

      <div className="wrap section">
        <h2>Let's create together.</h2>
        <p className="lede">Building worlds worthy of wonder.</p>
        <p className="email"><span>{EMAIL}</span><button type="button" onClick={copy}>{copied ? "Copied" : "Copy"}</button></p>
        {sent ? (
          <p className="empty-state">Thank you. In this preview, requests are not sent yet. Until the site is live, email {EMAIL}.</p>
        ) : (
          <form className="host-form" onSubmit={submit}>
            <label htmlFor="h-name"><Label>Your name</Label><input id="h-name" required value={form.name} onChange={set("name")} /></label>
            <label htmlFor="h-org"><Label>Team, school or community</Label><input id="h-org" value={form.org} onChange={set("org")} /></label>
            <label htmlFor="h-email"><Label>Email</Label><input id="h-email" type="email" required value={form.email} onChange={set("email")} /></label>
            <label htmlFor="h-size"><Label>Group size</Label><input id="h-size" inputMode="numeric" value={form.size} onChange={set("size")} /></label>
            <label htmlFor="h-note" className="wide"><Label>What future do you want to build together?</Label><textarea id="h-note" rows={4} value={form.note} onChange={set("note")} /></label>
            <button className="cta" type="submit">Bring the Lab to us</button>
          </form>
        )}
      </div>
    </div>
  );
}

function AddLink() {
  const { go } = useStore();
  return <button className="cta ghost" onClick={() => go({ page: "add" })}>Add your vision</button>;
}
