import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

// `npm run build` → normal multi-file build (GitHub / Lovable hosting).
// `npm run build:single` → one self-contained HTML file for the live preview.
export default defineConfig(({ mode }) => ({
  plugins: [react(), ...(mode === "single" ? [viteSingleFile()] : [])],
  build: mode === "single"
    ? { outDir: "dist-single", assetsInlineLimit: 100_000_000 }
    : { outDir: "dist", assetsInlineLimit: 0 },
  base: "./", // works at a domain root or a subpath like /database/
  server: { host: true, port: 8080 },
}));
