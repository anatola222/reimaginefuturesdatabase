# Garden of the Future

A values-first database of hopeful futures, organized by the D.R.E.A.M. Futures Framework
(Deep Nature Wisdom, Restorative Technology, Embodied Belonging, Architects of Awe, Mutual Abundance).
By Anatola Araba / R3imagine Story Lab.

## Run
npm install
npm run dev        # http://localhost:8080
npm run build      # production build in dist/ (for Lovable or any static host)

## Data
- src/data/values.ts: value clusters and raw tag mapping (curator-editable)
- src/data/visions.ts: participant responses
- src/data/worlds.ts: worlds; `hold: true` keeps a world off the site
- src/data/fieldguide.ts: the D.R.E.A.M. Field Guide

Approvals and mood boards are saved per browser. Move them to a database (e.g. Supabase) for a shared archive.

## Fonts
Headers use Osiris (falls back to Rajdhani). Add the Osiris font file to public/fonts and enable the @font-face in src/styles.css.
