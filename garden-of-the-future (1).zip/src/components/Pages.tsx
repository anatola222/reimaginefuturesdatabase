import { useMemo, useState } from "react";
import { DREAM, pillarById, type PillarId } from "../data/pillars";
import { TENSIONS, VALUES, valueById } from "../data/values";
import { VISIONS, type Vision } from "../data/visions";
import { WORLDS, thumbOf, worldById } from "../data/worlds";
import { pollValueCounts } from "../data/gatherings";
import { useStore } from "../lib/store";
import { kindred, valuesOf, visible } from "../lib/stats";
import { DreamStrip, Field, Label, ValueChip } from "./ui";

const uniq = (a: string[]) => [...new Set(a)].sort();
const who = (v: Vision) => (v.cohort === "youth" ? "Youth" : v.cohort === "adult" ? "Adult" : "Mixed ages");
const opts = (a: string[], all: string) => [{ v: "", l: all }, ...a.map((x) => ({ v: x, l: x }))];

function VisionCard({ v }: { v: Vision }) {
  const { approved, board, togglePin } = useStore();
  const held = valuesOf(v, approved);
  const k = `vision:${v.id}`;
  const t = TENSIONS.find((x) => x.id === v.tension);
  return (
    <article className={`vcard${t ? " tension" : ""}`}>
      <p className="vcard-d">{v.description}</p>
      {t && <p className="vcard-t"><b>Future to redesign · {t.name}.</b> {t.question}</p>}
      <div className="chips">{held.map((h) => <ValueChip key={h.id} id={h.id} source={h.source} />)}</div>
      <div className="vcard-meta">
        <span>{v.year} · {who(v)}</span>
        <span>{v.setting} · {v.technology}</span>
        <button className="pin" onClick={() => togglePin(k)} aria-pressed={board.includes(k)}>{board.includes(k) ? "Pinned" : "Pin"}</button>
      </div>
    </article>
  );
}

function Refine({ list }: { list: Vision[] }) {
  const [f, setF] = useState({ setting: "", aspiration: "", technology: "", year: "" });
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v });
  const shown = list.filter((v) =>
    (!f.setting || v.setting === f.setting) && (!f.aspiration || v.aspiration === f.aspiration) &&
    (!f.technology || v.technology === f.technology) &&
    (!f.year || String(v.year) === f.year));
  return (
    <>
      <div className="filters">
        <Field id="r-set" label="Setting" value={f.setting} onChange={set("setting")} options={opts(uniq(list.map((v) => v.setting)), "Any")} />
        <Field id="r-asp" label="Aspiration" value={f.aspiration} onChange={set("aspiration")} options={opts(uniq(list.map((v) => v.aspiration)), "Any")} />
        <Field id="r-tech" label="Technology" value={f.technology} onChange={set("technology")} options={opts(uniq(list.map((v) => v.technology)), "Any")} />
        <Field id="r-yr" label="Year" value={f.year} onChange={set("year")} options={opts(uniq(list.map((v) => String(v.year))), "Any")} />
      </div>
      <p className="count">{shown.length} of {list.length} visions</p>
      <div className="vgrid">{shown.map((v) => <VisionCard key={v.id} v={v} />)}</div>
    </>
  );
}

export function ValuePage({ id }: { id: string }) {
  const { approved, go } = useStore();
  const val = valueById(id);
  if (!val) return <div className="wrap section"><h1>That value isn't in the database.</h1></div>;
  const p = pillarById(val.pillar);
  const holders = visible().filter((v) => valuesOf(v, approved).some((h) => h.id === id));
  const youth = holders.filter((v) => v.cohort === "youth").length;
  const adult = holders.filter((v) => v.cohort === "adult").length;
  const polled = pollValueCounts()[id] ?? 0;
  const worlds = WORLDS.filter((w) => w.values.some((x) => x.id === id));
  const kin = kindred(id, approved);
  const bps = worlds.flatMap((w) => (w.blueprint ? [w.blueprint] : []));
  const pct = holders.length ? Math.round((youth / holders.length) * 100) : 0;

  return (
    <div className="wrap section page">
      <DreamStrip active={val.pillar === "S" ? ["E", "A"] : [val.pillar]} />
      <Label>{p.name}</Label>
      <h1>{val.name}</h1>
      <p className="quote">“{p.quote}”</p>

      <div className="stats">
        <div><span className="big">{holders.length}</span><Label>visions hold it</Label></div>
        {polled > 0 && <div><span className="big">{polled}</span><Label>chose it in a live poll</Label></div>}
        <div className="split">
          <Label>Youth {youth} · Adults {adult} · Mixed ages {holders.length - youth - adult}</Label>
          <div className="bar" role="img" aria-label={`${pct}% youth`}><span style={{ width: `${pct}%` }} /></div>
        </div>
      </div>

      {worlds.length > 0 && (
        <section className="block">
          <h2>Worlds that hold it</h2>
          <div className="wrow">
            {worlds.map((w) => {
              const x = w.values.find((y) => y.id === id)!;
              return (
                <button key={w.id} className="wmini" onClick={() => go({ page: "world", id: w.id })}>
                  <img src={thumbOf(w)} alt="" loading="lazy" width={320} height={320} />
                  <span className="wmini-t">{w.title}</span>
                  {x.excerpt && <span className="wmini-x">“{x.excerpt}”{x.source === "inferred" && <em> · inferred</em>}</span>}
                </button>
              );
            })}
          </div>
        </section>
      )}

      <section className="block">
        <h2>Visions that hold it</h2>
        <Refine list={holders} />
      </section>

      {kin.length > 0 && (
        <section className="block">
          <h2>Kindred values</h2>
          <div className="chips">{kin.map((k) => <ValueChip key={k.id} id={k.id} count={k.n} />)}</div>
        </section>
      )}

      {bps.length > 0 && (
        <section className="block">
          <h2>Experiential blueprint</h2>
          <div className="bp">
            <div><Label>Sensory cues</Label><ul>{bps.flatMap((b) => b.senses).slice(0, 6).map((s) => <li key={s}>{s}</li>)}</ul></div>
            <div><Label>Roleplay prompts</Label><ul>{bps.slice(0, 3).map((b) => <li key={b.roleplay}>{b.roleplay}</li>)}</ul></div>
            <div><Label>Design constraints</Label><ul>{bps.slice(0, 3).map((b) => <li key={b.constraint}>{b.constraint}</li>)}</ul></div>
          </div>
        </section>
      )}

      <p className="affirm">{val.affirmation}</p>
    </div>
  );
}

export function WorldPage({ id }: { id: string }) {
  const { approved, board, togglePin } = useStore();
  const w = worldById(id);
  if (!w) return <div className="wrap section"><h1>That world isn't in the database.</h1></div>;
  const echoes = (pv: string[]) => visible().filter((v) => v.description !== w.seed && valuesOf(v, approved).some((h) => pv.includes(h.id))).slice(0, 2);
  const k = `world:${w.id}`;
  const g = !!w.gathering;
  const affirmation = w.affirmation ?? valueById(w.values[0]?.id)?.affirmation;
  return (
    <div className="page">
      <div className="world-hero">
        <img src={w.image} alt={w.title} width={820} height={820} />
      </div>
      <div className="wrap section">
        <div className="chips glow">{w.values.map((v) => <ValueChip key={v.id} id={v.id} source={v.source} />)}</div>
        <h1>{w.title}</h1>
        <Label>{w.origin}</Label>
        {g && w.seed && (
          <blockquote className="words">
            <Label>In a participant's own words</Label>
            <p>“{w.seed}”</p>
          </blockquote>
        )}
        {!g && w.seed && <p className="lede">{w.seed}</p>}

        {w.day && (
          <section className="block">
            <h2>A day in the life</h2>
            <p className="prose">{w.day}</p>
          </section>
        )}

        <section className="block">
          <h2>The D.R.E.A.M. reading</h2>
          <ol className="reading">
            {DREAM.map((p) => {
              const r = w.reading?.[p];
              const held = w.values.filter((v) => valueById(v.id)?.pillar === p);
              const pv = held.map((v) => v.id);
              const present = r || held.length > 0;
              return (
                <li key={p} className={present ? "" : "empty"}>
                  <span className="rl">{p}</span>
                  <div>
                    <Label>{pillarById(p).name}</Label>
                    {r ? <p>{r.held}</p> : held.length > 0
                      ? <p>Holds {held.map((h) => valueById(h.id)?.name).join(" and ")}{held[0].excerpt ? <>: “{held[0].excerpt}”</> : "."}</p>
                      : <p>Not yet present in this world. What would it add?</p>}
                    {r?.tension && <p className="tension-note"><b>Future to redesign.</b> {r.tension}</p>}
                    {pv.length > 0 && echoes(pv).map((e) => <p key={e.id} className="echo">Echo from the room: “{e.description}” <span>· {who(e)}, {e.year}</span></p>)}
                  </div>
                </li>
              );
            })}
          </ol>
        </section>

        {w.blueprint && (
          <section className="block">
            <h2>Experiential blueprint</h2>
            <div className="bp">
              <div><Label>Sensory cues</Label><ul>{w.blueprint.senses.map((s) => <li key={s}>{s}</li>)}</ul></div>
              <div><Label>Roleplay prompt</Label><p>{w.blueprint.roleplay}</p></div>
              <div><Label>Design constraint</Label><p>{w.blueprint.constraint}</p></div>
            </div>
          </section>
        )}

        {affirmation && <p className="affirm">{affirmation}</p>}
        <button className="cta" onClick={() => togglePin(k)} aria-pressed={board.includes(k)}>
          {board.includes(k) ? "Pinned to mood board" : "Pin to mood board"}
        </button>
      </div>
    </div>
  );
}

export function Archive() {
  const { approved } = useStore();
  const [value, setValue] = useState("");
  const [pillar, setPillar] = useState("");
  const [source, setSource] = useState("");
  const [cohort, setCohort] = useState("");
  const list = visible().filter((v) => {
    const held = valuesOf(v, approved);
    return (!value || held.some((h) => h.id === value && (!source || h.source === source))) &&
      (!source || held.some((h) => h.source === source)) &&
      (!pillar || held.some((h) => valueById(h.id)?.pillar === pillar)) &&
      (!cohort || v.cohort === cohort);
  });
  return (
    <div className="wrap section page">
      <h1>Visions archive</h1>
      <p className="lede">Every vision, searched first by what it values.</p>
      <div className="filters">
        <Field id="a-val" label="01 — Value" value={value} onChange={setValue} options={[{ v: "", l: "Any value" }, ...VALUES.map((v) => ({ v: v.id, l: v.name }))]} />
        <Field id="a-pil" label="02 — Pillar" value={pillar} onChange={setPillar} options={[{ v: "", l: "Any pillar" }, ...[...DREAM, "S" as PillarId].map((p) => ({ v: p, l: pillarById(p).name }))]} />
        <Field id="a-src" label="Stated or inferred" value={source} onChange={setSource} options={[{ v: "", l: "Both" }, { v: "stated", l: "Stated by participants" }, { v: "inferred", l: "Inferred, curator approved" }]} />
        <Field id="a-coh" label="Cohort" value={cohort} onChange={setCohort} options={[{ v: "", l: "Everyone" }, { v: "youth", l: "Youth" }, { v: "adult", l: "Adults" }, { v: "mixed", l: "Mixed ages" }].filter((o) => !o.v || visible().some((x) => x.cohort === o.v))} />
      </div>
      <Refine list={list} />
    </div>
  );
}

export function Board() {
  const { board, approved, togglePin, go } = useStore();
  const items = board.map((k) => {
    const [kind, id] = k.split(":");
    return kind === "world" ? { k, world: worldById(id) } : { k, vision: VISIONS.find((v) => v.id === id) };
  });
  const balance = useMemo(() => {
    const c: Record<string, number> = { D: 0, R: 0, E: 0, A: 0, M: 0 };
    for (const it of items) {
      const ids = it.world ? it.world.values.map((v) => v.id) : it.vision ? valuesOf(it.vision, approved).map((h) => h.id) : [];
      ids.forEach((i) => { const p = valueById(i)?.pillar; if (p && p in c) c[p]++; });
    }
    return c;
  }, [items, approved]);
  const max = Math.max(1, ...Object.values(balance));
  const weakest = DREAM.filter((p) => balance[p] === Math.min(...DREAM.map((q) => balance[q])));

  return (
    <div className="wrap section page">
      <h1>Mood board</h1>
      <p className="lede">Pin worlds and visions. The balance meter shows which pillars your project holds.</p>
      <div className="meter">
        {DREAM.map((p) => (
          <div key={p} className="meter-col">
            <div className="meter-track"><span style={{ height: `${(balance[p] / max) * 100}%` }} /></div>
            <span className="meter-l">{p}</span><span className="meter-n">{balance[p]}</span>
          </div>
        ))}
      </div>
      {items.length > 0 && <p className="muted">To balance this board, look for {weakest.map((p) => pillarById(p).name).join(" or ")}.</p>}
      {items.length === 0 && <p className="empty-state">Nothing pinned yet. Open any world or vision and choose Pin.</p>}
      <div className="vgrid">
        {items.map((it) => it.world ? (
          <article key={it.k} className="vcard">
            <button className="wmini" onClick={() => go({ page: "world", id: it.world!.id })}>
              <img src={thumbOf(it.world)} alt="" width={320} height={320} /><span className="wmini-t">{it.world.title}</span>
            </button>
            <button className="pin" onClick={() => togglePin(it.k)}>Remove</button>
          </article>
        ) : it.vision ? <VisionCard key={it.k} v={it.vision} /> : null)}
      </div>
    </div>
  );
}

export function Curate() {
  const { approved, toggleApproved } = useStore();
  const queue = VISIONS.filter((v) => v.inferred.length && !v.hidden);
  return (
    <div className="wrap section page">
      <h1>Curator review</h1>
      <p className="lede">AI suggested these values from each vision's description. Only approved values count anywhere in the database.</p>
      <div className="vgrid">
        {queue.map((v) => (
          <article key={v.id} className="vcard">
            <p className="vcard-d">{v.description}</p>
            <div className="chips">
              {v.inferred.map((id) => {
                const k = `${v.id}:${id}`, on = approved.has(k);
                return (
                  <button key={id} className={`chip inferred${on ? "" : " off"}`} onClick={() => toggleApproved(k)} aria-pressed={on}>
                    {valueById(id)?.name} <span className="chip-tag">{on ? "approved" : "pending"}</span>
                  </button>
                );
              })}
            </div>
            <div className="vcard-meta"><span>{v.year} · {who(v)}</span></div>
          </article>
        ))}
      </div>
    </div>
  );
}

export function Promise() {
  const { go } = useStore();
  const lines: [string, string][] = [
    ["People are the authors.", "Every vision here was written or drawn by a person. AI never adds a future to this archive."],
    ["Inference is always labeled.", "When AI suggests a value, it is marked inferred, shown in a dashed outline, and counted only after a curator approves it."],
    ["We listen to groups, not track individuals.", "The database stores cohort, workshop and year. No names, faces or personal profiles."],
    ["The hard futures stay visible.", "Visions of data-worship or endless growth remain as futures to redesign, so we can talk about them openly."],
    ["Many ways of knowing.", "Indigenous, African, Afrofuturist, Global South and ancestral knowledge sit beside technical sources."],
    ["We count the cost.", "AI images carry an energy footprint. The world images here are compressed and loaded only when needed, and the app runs without calling any AI model."],
  ];
  return (
    <div className="wrap section page">
      <Label>A statement for the future of AI</Label>
      <h1>Humans dream. AI helps us listen.</h1>
      <p className="lede">In a moment when AI is often sold as the author of the future, this database takes a different position. The future belongs to the people imagining it. AI is a tool for hearing them more clearly.</p>
      <ol className="promise">
        {lines.map(([h, b]) => <li key={h}><h3>{h}</h3><p>{b}</p></li>)}
      </ol>
      <button className="cta" onClick={() => go({ page: "curate" })}>See the curator review</button>
    </div>
  );
}

