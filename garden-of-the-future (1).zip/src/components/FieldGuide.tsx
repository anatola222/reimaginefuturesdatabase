import { useEffect, useMemo, useState } from "react";
import { DREAM, pillarById, type PillarId } from "../data/pillars";
import { GUIDE, GUIDE_INTRO, splitKind } from "../data/fieldguide";
import { DreamStrip, Label } from "./ui";

interface Orb { key: string; pillar: PillarId; cat: string; n: number; kind?: string; text: string; x: number; y: number; r: number }
interface Hub { key: string; pillar: PillarId; title: string; n: number; x: number; y: number }

const CLUSTER_H = 150;
const GOLD = 2.39996; // golden angle, keeps orbs from overlapping

function layout(cols: PillarId[], width: number) {
  const cw = width / cols.length;
  const orbs: Orb[] = [], hubs: Hub[] = [], links: [number, number, number, number, boolean][] = [];
  let height = 0;
  cols.forEach((pid, ci) => {
    const g = GUIDE.find((x) => x.id === pid)!;
    const cats = [...g.boxes.map((b) => ({ n: b.n, title: b.title, lines: b.lines })),
      ...(g.tryThis ? [{ n: 0, title: "Try one this week", lines: g.tryThis.map((t) => `Try: ${t}`) }] : [])];
    const top: [number, number] = [cw * ci + cw / 2, 40];
    let prev = top;
    cats.forEach((c, k) => {
      const wobble = (k % 2 ? 1 : -1) * cw * 0.12;
      const cx = cw * ci + cw / 2 + wobble, cy = 110 + k * CLUSTER_H;
      hubs.push({ key: `${pid}-${c.n}`, pillar: pid, title: c.title, n: c.n, x: cx, y: cy });
      links.push([prev[0], prev[1], cx, cy, true]);
      prev = [cx, cy];
      c.lines.forEach((line, i) => {
        const a = i * GOLD + k, rad = 34 + 13 * Math.sqrt(i + 1);
        const x = Math.min(cw * (ci + 1) - 16, Math.max(cw * ci + 16, cx + Math.cos(a) * rad * (cw / 220)));
        const y = cy + Math.sin(a) * rad * 0.8;
        const { kind, text } = splitKind(line);
        orbs.push({ key: `${pid}-${c.n}-${i}`, pillar: pid, cat: c.title, n: c.n, kind, text, x, y, r: kind ? 9 : 6 });
        links.push([cx, cy, x, y, false]);
      });
      height = Math.max(height, cy + 90);
    });
  });
  return { orbs, hubs, links, height };
}

function usePortrait() {
  const q = "(max-width: 760px)";
  const [p, setP] = useState(() => matchMedia(q).matches);
  useEffect(() => { const m = matchMedia(q); const on = () => setP(m.matches); m.addEventListener("change", on); return () => m.removeEventListener("change", on); }, []);
  return p;
}

export default function FieldGuide() {
  const narrow = usePortrait();
  const [focus, setFocus] = useState<PillarId | null>(null);
  const [sel, setSel] = useState<Orb | null>(null);
  const cols: PillarId[] = narrow ? [focus ?? "D"] : DREAM;
  const W = narrow ? 400 : 1000;
  const { orbs, hubs, links, height } = useMemo(() => layout(cols, W), [cols.join(), W]);
  const lit = (p: PillarId) => !focus || focus === p;
  const g = focus ? GUIDE.find((x) => x.id === focus) : null;

  return (
    <div className="wrap section page guide">
      <Label>Field guide</Label>
      <h1>{GUIDE_INTRO.title}</h1>
      <p className="lede">{GUIDE_INTRO.sub}</p>
      <p className="prose">{GUIDE_INTRO.body}</p>

      <DreamStrip size="lg" active={focus ? [focus] : narrow ? ["D"] : undefined} onPick={(p) => { setFocus(focus === p && !narrow ? null : p); setSel(null); }} />
      {g && <p className="pillar-line"><b>{pillarById(g.id).name}. What it means for you:</b> {g.meaning}</p>}
      <p className="muted small">{orbs.length} orbs of knowledge. Larger orbs are resources to read, watch or explore. Tap any orb to open it.</p>

      <div className="orbfield" style={{ aspectRatio: `${W} / ${height}` }}>
        <svg viewBox={`0 0 ${W} ${height}`} preserveAspectRatio="none" aria-hidden="true">
          {links.map(([x1, y1, x2, y2, spine], i) => (
            <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} className={spine ? "ln spine" : "ln"} />
          ))}
        </svg>
        {!narrow && DREAM.map((p, i) => (
          <span key={p} className={`col-head${lit(p) ? "" : " dim"}`} style={{ left: `${((i + 0.5) / 5) * 100}%`, top: `${(40 / height) * 100}%` }}>{p}</span>
        ))}
        {hubs.map((h) => (
          <span key={h.key} className={`hub${lit(h.pillar) ? "" : " dim"}`} style={{ left: `${(h.x / W) * 100}%`, top: `${(h.y / height) * 100}%` }}>
            <i aria-hidden="true" /><em>{h.title}</em>
          </span>
        ))}
        {orbs.map((o, i) => (
          <button key={o.key}
            className={`orb${o.kind ? " res" : ""}${o.kind === "Community vision" ? " vis" : ""}${o.kind === "Try" ? " try" : ""}${lit(o.pillar) ? " lit" : " dim"}${sel?.key === o.key ? " sel" : ""}`}
            style={{ left: `${(o.x / W) * 100}%`, top: `${(o.y / height) * 100}%`, ["--r" as string]: `${o.r * 2}px`, animationDelay: `${(i % 17) * 0.23}s` }}
            onClick={() => setSel(o)} aria-label={`${o.kind ? o.kind + ": " : ""}${o.text.slice(0, 80)}`} title={o.text.slice(0, 90)} />
        ))}
      </div>

      {sel && (
        <aside className="orb-panel" role="dialog" aria-label="Orb detail">
          <div className="orb-panel-in">
            <Label>{pillarById(sel.pillar).name} · {sel.n ? `${sel.n}. ` : ""}{sel.cat}</Label>
            {sel.kind && <span className="kind">{sel.kind}</span>}
            <p>{sel.text}</p>
            <button className="close" onClick={() => setSel(null)}>Close</button>
          </div>
        </aside>
      )}
    </div>
  );
}
