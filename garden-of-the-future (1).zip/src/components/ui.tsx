import type { ReactNode } from "react";
import { DREAM, pillarById, type PillarId } from "../data/pillars";
import { valueById } from "../data/values";
import { useStore } from "../lib/store";

/** The D·R·E·A·M strip from the framework book: the active letter sits in a lit column. */
export function DreamStrip({ active, size = "sm", onPick }: { active?: PillarId[]; size?: "sm" | "lg"; onPick?: (p: PillarId) => void }) {
  return (
    <div className={`dream dream-${size}`} role={onPick ? "group" : undefined} aria-label="D.R.E.A.M. pillars">
      {DREAM.map((p) => {
        const on = active?.includes(p);
        const Tag = onPick ? "button" : "span";
        return (
          <Tag key={p} className={`dream-l${on ? " on" : ""}`} onClick={onPick ? () => onPick(p) : undefined}
            title={pillarById(p).name} aria-pressed={onPick ? on : undefined}>
            {p}
          </Tag>
        );
      })}
    </div>
  );
}

export const Label = ({ children }: { children: ReactNode }) => <div className="label">{children}</div>;

export function ValueChip({ id, source, count }: { id: string; source?: "stated" | "inferred"; count?: number }) {
  const { go } = useStore();
  const v = valueById(id);
  if (!v) return null;
  return (
    <button className={`chip${source === "inferred" ? " inferred" : ""}`} onClick={() => go({ page: "value", id })}
      title={source === "inferred" ? "Inferred by AI, approved by curator" : "Named by participants"}>
      <span className="chip-letter">{v.pillar === "S" ? "✦" : v.pillar}</span>
      {v.name}
      {count !== undefined && <span className="chip-n">{count}</span>}
      {source === "inferred" && <span className="chip-tag">inferred</span>}
    </button>
  );
}

export function Segmented<T extends string>({ options, value, onChange, label }: {
  options: { v: T; l: string }[]; value: T; onChange: (v: T) => void; label: string;
}) {
  return (
    <div className="seg" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button key={o.v} role="radio" aria-checked={value === o.v} className={value === o.v ? "on" : ""} onClick={() => onChange(o.v)}>
          {o.l}
        </button>
      ))}
    </div>
  );
}

export function Field({ id, label, value, onChange, options }: {
  id: string; label: string; value: string; onChange: (v: string) => void; options: { v: string; l: string }[];
}) {
  return (
    <label className="field" htmlFor={id}>
      <Label>{label}</Label>
      <select id={id} value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
      </select>
    </label>
  );
}

export const Note = ({ children }: { children: ReactNode }) => <p className="note">{children}</p>;
