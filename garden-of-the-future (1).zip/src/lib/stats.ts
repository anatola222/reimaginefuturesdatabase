import { VALUES, normalizeTag } from "../data/values";
import { VISIONS, type Vision } from "../data/visions";
import { pollValueCounts } from "../data/gatherings";

export type CohortFilter = "all" | "youth" | "adult" | "mixed";
export interface HeldValue { id: string; source: "stated" | "inferred" }

/** Values a vision holds: stated tags normalized to clusters, plus approved inferred ones. */
export function valuesOf(v: Vision, approved: Set<string>): HeldValue[] {
  const out = new Map<string, HeldValue>();
  for (const t of v.stated) {
    const id = normalizeTag(t);
    if (id) out.set(id, { id, source: "stated" });
  }
  for (const id of v.inferred) {
    if (!out.has(id) && approved.has(`${v.id}:${id}`)) out.set(id, { id, source: "inferred" });
  }
  return [...out.values()];
}

export function matchesCohort(v: Vision, f: CohortFilter) {
  if (f === "all") return true;
  return v.cohort === f;
}

// Public site shows hopeful futures only. Tension visions stay in the data for research.
export const visible = () => VISIONS.filter((v) => !v.hidden && !v.tension);

export function valueCounts(f: CohortFilter, approved: Set<string>) {
  const counts: Record<string, number> = Object.fromEntries(VALUES.map((v) => [v.id, 0]));
  for (const v of visible().filter((x) => matchesCohort(x, f)))
    for (const h of valuesOf(v, approved)) counts[h.id]++;
  // Gathering polls are mixed-age, aggregate answers: add them to Everyone and Mixed ages.
  if (f === "all" || f === "mixed") for (const [id, n] of Object.entries(pollValueCounts())) counts[id] = (counts[id] ?? 0) + n;
  return counts;
}

/** Pairs of values named together by the same participant. */
export function coOccurrence(f: CohortFilter, approved: Set<string>) {
  const pairs = new Map<string, number>();
  for (const v of visible().filter((x) => matchesCohort(x, f))) {
    const ids = valuesOf(v, approved).map((h) => h.id).sort();
    for (let i = 0; i < ids.length; i++)
      for (let j = i + 1; j < ids.length; j++) {
        const k = `${ids[i]}|${ids[j]}`;
        pairs.set(k, (pairs.get(k) ?? 0) + 1);
      }
  }
  return pairs;
}

export function kindred(id: string, approved: Set<string>) {
  const res: { id: string; n: number }[] = [];
  coOccurrence("all", approved).forEach((n, k) => {
    const [a, b] = k.split("|");
    if (a === id) res.push({ id: b, n });
    else if (b === id) res.push({ id: a, n });
  });
  return res.sort((x, y) => y.n - x.n).slice(0, 5);
}

/** Every inferred suggestion, for the curator queue. Default: all approved. */
export const ALL_INFERRED = VISIONS.flatMap((v) => v.inferred.map((id) => `${v.id}:${id}`));
