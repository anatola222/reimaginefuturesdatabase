import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { ALL_INFERRED, type CohortFilter } from "./stats";

// Per-viewer state kept in browser storage. For a shared, multi-user archive,
// move `approved` and `board` into a database (e.g. Supabase in Lovable).
const load = <T,>(k: string, d: T): T => {
  try { const s = localStorage.getItem(k); return s ? (JSON.parse(s) as T) : d; } catch { return d; }
};
const save = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } };

export type Route =
  | { page: "home" } | { page: "archive" } | { page: "board" }
  | { page: "promise" } | { page: "curate" } | { page: "guide" } | { page: "add" } | { page: "host" }
  | { page: "value"; id: string } | { page: "world"; id: string };

export function parseHash(h: string): Route {
  const t = h.replace(/^#/, "");
  if (t.startsWith("value-")) return { page: "value", id: t.slice(6) };
  if (t.startsWith("world-")) return { page: "world", id: t.slice(6) };
  if (["archive", "board", "promise", "curate", "guide", "add", "host"].includes(t)) return { page: t as "archive" };
  return { page: "home" };
}
export const toHash = (r: Route) =>
  r.page === "home" ? "" : r.page === "value" || r.page === "world" ? `${r.page}-${r.id}` : r.page;

interface Store {
  route: Route; go: (r: Route) => void;
  cohort: CohortFilter; setCohort: (c: CohortFilter) => void;
  approved: Set<string>; toggleApproved: (k: string) => void;
  board: string[]; togglePin: (k: string) => void;
}
const Ctx = createContext<Store>(null!);
export const useStore = () => useContext(Ctx);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>(() => parseHash(location.hash));
  const [cohort, setCohort] = useState<CohortFilter>("all");
  const [approvedList, setApproved] = useState<string[]>(() => load("rfd:approved", ALL_INFERRED));
  const [board, setBoard] = useState<string[]>(() => load("rfd:board", []));

  useEffect(() => {
    const on = () => setRoute(parseHash(location.hash));
    addEventListener("hashchange", on);
    return () => removeEventListener("hashchange", on);
  }, []);
  useEffect(() => save("rfd:approved", approvedList), [approvedList]);
  useEffect(() => save("rfd:board", board), [board]);

  const value = useMemo<Store>(() => ({
    route,
    go: (r) => {
      setRoute(r);
      try { history.replaceState(null, "", toHash(r) ? `#${toHash(r)}` : location.pathname); } catch { /* sandboxed */ }
      window.scrollTo({ top: 0 });
    },
    cohort, setCohort,
    approved: new Set(approvedList),
    toggleApproved: (k) => setApproved((a) => (a.includes(k) ? a.filter((x) => x !== k) : [...a, k])),
    board,
    togglePin: (k) => setBoard((b) => (b.includes(k) ? b.filter((x) => x !== k) : [...b, k])),
  }), [route, cohort, approvedList, board]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
