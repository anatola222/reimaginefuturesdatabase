import { StoreProvider, useStore, type Route } from "./lib/store";
import Home from "./components/Home";
import FieldGuide from "./components/FieldGuide";
import { AddVision, Host } from "./components/Gather";
import { Archive, Board, Curate, Promise, ValuePage, WorldPage } from "./components/Pages";

const NAV: { r: Route; l: string }[] = [
  { r: { page: "home" }, l: "Worlds" },
  { r: { page: "guide" }, l: "Field guide" },
  { r: { page: "archive" }, l: "Archive" },
  { r: { page: "host" }, l: "Lab" },
  { r: { page: "board" }, l: "Mood board" },
  { r: { page: "promise" }, l: "AI promise" },
];

function Shell() {
  const { route, go, board } = useStore();
  const page = (() => {
    switch (route.page) {
      case "value": return <ValuePage id={route.id} />;
      case "world": return <WorldPage id={route.id} />;
      case "guide": return <FieldGuide />;
      case "archive": return <Archive />;
      case "board": return <Board />;
      case "promise": return <Promise />;
      case "curate": return <Curate />;
      case "add": return <AddVision />;
      case "host": return <Host />;
      default: return <Home />;
    }
  })();
  return (
    <>
      <nav className="top">
        <div className="top-in">
          <button className="brand" onClick={() => go({ page: "home" })} aria-label="Garden of the Future home">
            <span className="brand-mark" aria-hidden="true" />Garden of the Future
          </button>
          <div className="links">
            {NAV.map((n) => (
              <button key={n.l} className={route.page === n.r.page ? "on" : ""} onClick={() => go(n.r)}>
                {n.l}{n.r.page === "board" && board.length > 0 && <span className="badge">{board.length}</span>}
              </button>
            ))}
          </div>
          <button className="nav-cta" onClick={() => go({ page: "add" })}>Add your vision</button>
        </div>
      </nav>
      <main key={JSON.stringify(route)}>{page}</main>
      <footer className="foot">
        Built by Professor Anatola Araba · R3imagine Story Lab · D.R.E.A.M. Futures Framework
      </footer>
    </>
  );
}

export default function App() {
  return <StoreProvider><Shell /></StoreProvider>;
}
