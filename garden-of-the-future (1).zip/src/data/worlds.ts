import type { PillarId } from "./pillars";

// Images: src/assets/worlds/<id>.webp (large) and <id>-sm.webp (thumbnail), loaded only when shown.
const LARGE = import.meta.glob("../assets/worlds/*.webp", { eager: true, import: "default", query: "?url" }) as Record<string, string>;
const img = (id: string) => LARGE[`../assets/worlds/${id}.webp`];
export const thumbOf = (w: { id: string }) => LARGE[`../assets/worlds/${w.id}-sm.webp`] ?? img(w.id);

export interface WorldValue { id: string; source: "stated" | "inferred"; excerpt: string }
export interface World {
  id: string;
  title: string;
  image: string;
  origin: string;
  gathering?: string; // id in gatherings.ts
  seed?: string; // participant's own words when real
  day?: string;
  values: WorldValue[];
  reading?: Partial<Record<PillarId, { held: string; tension?: string }>>;
  blueprint?: { senses: string[]; roleplay: string; constraint: string };
  affirmation?: string;
  hold?: boolean; // kept off the site: people shown are not diverse enough
}

// Atlanta 2026: seeds are participants' exact words. Values are inferred from those words.
const ATL = "Mixed ages · 2026";
const ATLANTA_WORLDS: World[] = [
  { id: "sun-kissed-shore", title: "Sun-Kissed Shore", image: img("sun-kissed-shore"), origin: ATL, gathering: "atl-2026", hold: true,
    seed: "Visitors land on the beach and they see blue water, smell fresh fruit and the buildings are built o brick and wood. The people are sun kissed and live in the present in community.",
    values: [
      { id: "community", source: "inferred", excerpt: "live in the present in community" },
      { id: "nourishment", source: "inferred", excerpt: "smell fresh fruit" },
      { id: "peace", source: "inferred", excerpt: "live in the present" },
    ] },
  { id: "three-moons", title: "Three Moons", image: img("three-moons"), origin: ATL, gathering: "atl-2026", hold: true,
    seed: "Tall skyscrapers covered in flora, with clean air and recyclable energy. Orange skies, pink and purple swirls with a deep burnt orange sun, African architecture and renewable energy. 3 moons.",
    values: [
      { id: "sustainability", source: "inferred", excerpt: "recyclable energy … renewable energy" },
      { id: "harmony", source: "inferred", excerpt: "skyscrapers covered in flora, with clean air" },
      { id: "healing", source: "inferred", excerpt: "African architecture" },
    ] },
  { id: "the-communion", title: "The Communion", image: img("the-communion"), origin: ATL, gathering: "atl-2026", hold: true,
    seed: "Multicultural people communing with one another with dance, food, praise, education and celebration of each other’s lives.",
    values: [
      { id: "community", source: "inferred", excerpt: "communing with one another" },
      { id: "respect", source: "inferred", excerpt: "multicultural people … celebration of each other’s lives" },
      { id: "joy", source: "inferred", excerpt: "dance, food … celebration" },
      { id: "faith", source: "inferred", excerpt: "praise" },
      { id: "curiosity", source: "inferred", excerpt: "education" },
    ] },
  { id: "higher-frequency", title: "Higher Frequency", image: img("higher-frequency"), origin: ATL, gathering: "atl-2026", hold: true,
    seed: "As they land they see a prosperous civilization with cities that do not hinder nature. They notice everyone seems connected and as if they all are connected to one another but also of a higher freq",
    values: [
      { id: "harmony", source: "inferred", excerpt: "cities that do not hinder nature" },
      { id: "interconnection", source: "inferred", excerpt: "everyone seems connected" },
      { id: "abundance", source: "inferred", excerpt: "a prosperous civilization" },
      { id: "reverence", source: "inferred", excerpt: "of a higher freq" },
    ] },
  { id: "sea-of-space", title: "Sea of Space", image: img("sea-of-space"), origin: ATL, gathering: "atl-2026", hold: true,
    seed: "The people are hybrids from different species, all evolved to live in this dimension called the “Sea Of Space” where everything below is water and everything above is purple galactic sky",
    values: [
      { id: "imagination", source: "inferred", excerpt: "this dimension called the “Sea Of Space”" },
      { id: "respect", source: "inferred", excerpt: "hybrids from different species" },
    ] },
  { id: "shifting-sands", title: "Shifting Sands", image: img("shifting-sands"), origin: ATL, gathering: "atl-2026",
    seed: "The visitors will see desolation. The people are meek, and the terrain is grand. The sand shifts like waves, and so big civilizations are impossible. The people are small in stature, very agile.",
    values: [
      { id: "harmony", source: "inferred", excerpt: "the terrain is grand … big civilizations are impossible" },
      { id: "respect", source: "inferred", excerpt: "the people are meek" },
    ] },
];

// Library worlds: images only so far. Titles are working titles; values are inferred from the image.
const L = (id: string, title: string, values: [string, string][], hold?: boolean): World => ({
  id, title, image: img(id), origin: "Vision library", hold,
  values: values.map(([v, excerpt]) => ({ id: v, source: "inferred" as const, excerpt })),
});
const LIBRARY_WORLDS: World[] = [
  L("dome-commons", "Dome Commons", [["community", ""], ["nourishment", ""], ["harmony", ""], ["joy", ""]]),
  L("reef-towers", "Reef Towers", [["harmony", ""], ["sustainability", ""], ["healing", ""], ["reverence", ""]]),
  L("meadow-street", "Meadow Avenue", [["harmony", ""], ["peace", ""], ["family", ""]]),
  L("canopy-terraces", "Canopy Terraces", [["harmony", ""], ["curiosity", ""], ["healing", ""], ["abundance", ""]]),
  L("pink-lake", "Blossom Lake District", [["joy", ""], ["family", ""], ["harmony", ""]]),
  L("solar-playa", "Solar Playa", [["imagination", ""], ["freedom", ""], ["community", ""], ["joy", ""]]),
  L("treehouse-city", "Treehouse City", [["family", ""], ["harmony", ""], ["community", ""]]),
  L("lantern-rooftop", "Lantern Rooftop", [["healing", ""], ["integrity", ""], ["peace", ""]]),
  L("tide-pantry", "Tide Pantry", [["abundance", ""], ["nourishment", ""], ["community", ""]]),
  L("honeycomb-plaza", "Honeycomb Plaza", [["community", "a crowded, mixed public plaza"], ["joy", "children cycling by the fountain"], ["harmony", "trees growing from the terraces"]]),
  L("prism-garden", "Prism Garden", [["joy", "rainbow robes and flowers"], ["peace", "people resting by the falls"], ["imagination", "glowing sky gardens"]]),
  L("canal-park", "Canal Park", [["harmony", "a city threaded with water and trees"], ["family", "families walking the canal"], ["health", "open green paths"]]),
  L("earthrise-gardens", "Earthrise Gardens", [["harmony", "homes buried in gardens"], ["sustainability", "solar panels and wind turbines"]]),
  L("cloud-isles", "Cloud Isles", [["imagination", "cities floating above the clouds"], ["joy", "a rainbow over the isles"]]),
  L("hologram-terraces", "Hologram Terraces", [["harmony", "balconies spilling with plants"], ["interconnection", "glowing holograms between buildings"]]),
  L("crater-village", "Crater Village", [["harmony", "homes built into the hills"], ["courage", "a settlement in rugged land"]]),
  L("redwood-river", "Redwood River", [["harmony", "treehouses among redwoods"], ["sustainability", "solar roofs"], ["peace", "a quiet river at dusk"]]),
  L("waterfall-glade", "Waterfall Glade", [["healing", "light circles for healing in the forest"], ["reverence", "glowing figures by the falls"], ["harmony", "a river glade"]]),
  L("aurora-rings", "Aurora Rings", [["harmony", "vine-covered towers"], ["imagination", "auroras over a ringed city"]]),
  L("glass-dome-lounge", "Glass Dome Lounge", [["imagination", "winged figures over a pool"], ["peace", "soft lounges under glass domes"]]),
  L("violet-greenhouses", "Violet Greenhouses", [["nourishment", "glowing greenhouses"], ["imagination", "a violet world under three planets"]]),
  L("orbital-domes", "Orbital Domes", [["imagination", "domed cities among the stars"]]),
  L("garden-village", "Garden Village", [["nourishment", "terraced vegetable gardens"], ["community", "neighbors tending shared plots"], ["peace", "thatched homes in a quiet valley"]]),
  L("jungle-towers", "Jungle Towers", [["harmony", "towers grown into the jungle"], ["nourishment", "planted walkways"], ["sustainability", "waterfalls and green light"]]),
  L("waterfall-energy", "Waterfall Energy", [["sustainability", "solar and wind among the falls"], ["harmony", "a living waterfall valley"]]),
  L("star-portal", "Star Portal", [["curiosity", "a crowd before a portal to the cosmos"], ["reverence", "a galaxy overhead"]]),
  L("golden-sea", "Golden Sea", [["reverence", "a sea of golden light"], ["peace", "still water at dawn"]]),
  L("saucer-family", "Saucer Family", [["family", "a family dressed for the future"], ["joy", "children laughing"]], true),
  L("bubble-city", "Bubble City", [["joy", "children playing in the water"], ["imagination", "glowing bubble homes"]], true),
  L("lakeside-spiral", "Lakeside Spiral", [["harmony", "a spiral tree by the lake"], ["family", "friends walking hand in hand"]], true),
];

const ALL = [...LIBRARY_WORLDS, ...ATLANTA_WORLDS];
/** Worlds shown on the site. Held worlds stay in the code, flip `hold` to show one. */
export const WORLDS: World[] = ALL.filter((w) => !w.hold);
export const HELD: World[] = ALL.filter((w) => w.hold);
export const worldById = (id: string) => ALL.find((w) => w.id === id && !w.hold);
