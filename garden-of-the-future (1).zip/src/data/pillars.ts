// D.R.E.A.M. Futures Framework — Designing Regenerative, Equitable, and Abundant Models
// Anatola Araba / R3imagine Story Lab. Pillar text is editable by the curator.

export type PillarId = "D" | "R" | "E" | "A" | "M" | "S";

export interface Pillar {
  id: PillarId;
  name: string;
  short: string;
  description: string;
  quote: string;
  color: string; // CSS var name
}

export const PILLARS: Pillar[] = [
  {
    id: "D",
    name: "Deep Nature Wisdom",
    short: "Deep Nature",
    description:
      "Design in partnership with the intelligence of the Earth. Nature is the original blueprint for design, technology, and community, never a backdrop.",
    quote: "Every world change begins as a radical act of imagination.",
    color: "--d",
  },
  {
    id: "R",
    name: "Restorative Technology",
    short: "Restorative Tech",
    description:
      "Innovation that heals instead of harms, guided by Ubuntu: I am because we are. Tools that archive cultural memory and optimize for collective wellbeing.",
    quote: "Culture is coded in our stories of what is possible.",
    color: "--r",
  },
  {
    id: "E",
    name: "Embodied Belonging",
    short: "Belonging",
    description:
      "The future begins in the bonds between us. Belonging is as essential as food, water, and oxygen.",
    quote: "Control the imagination and you control the future.",
    color: "--e",
  },
  {
    id: "A",
    name: "Architects of Awe",
    short: "Awe",
    description:
      "Futures that nourish our collective joy, celebrate our aliveness, and make wonder a civic right.",
    quote: "I am a builder of new worlds.",
    color: "--a",
  },
  {
    id: "M",
    name: "Mutual Abundance",
    short: "Abundance",
    description:
      "Economies rooted in reciprocity, generosity, and shared thriving. Forests don't extract, they circulate. Rivers don't charge interest.",
    quote: "Innovation is a conversation between courage and curiosity.",
    color: "--m",
  },
  {
    id: "S",
    name: "Spirit & Meaning",
    short: "Spirit",
    description: "A nebula bridging Belonging and Awe: faith, gratitude, and reverence for the mystery.",
    quote: "We are held by something larger than ourselves.",
    color: "--s",
  },
];

export const DREAM: PillarId[] = ["D", "R", "E", "A", "M"];
export const pillarById = (id: PillarId) => PILLARS.find((p) => p.id === id)!;
