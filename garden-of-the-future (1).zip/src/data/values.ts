import type { PillarId } from "./pillars";

// Value Constellations: participants' raw Values tags normalize into these clusters.
// Curator-editable. `tags` are the raw words participants actually wrote.
export interface ValueCluster {
  id: string;
  name: string;
  pillar: PillarId;
  tags: string[];
  affirmation: string;
}

export const VALUES: ValueCluster[] = [
  // D
  { id: "harmony", name: "Harmony with Nature", pillar: "D", tags: ["harmony with nature", "the earth", "nature"], affirmation: "I am in partnership with the living Earth." },
  { id: "sustainability", name: "Sustainability", pillar: "D", tags: ["sustainability", "regenerative"], affirmation: "I am the bridge between ancient wisdom and emerging futures." },
  // R
  { id: "interconnection", name: "Interconnection & Communication", pillar: "R", tags: ["communication", "understanding", "perspective", "everyone connected"], affirmation: "I am because we are." },
  { id: "integrity", name: "Integrity & Ethics", pillar: "R", tags: ["integrity", "morality", "humanity"], affirmation: "I build tools that heal." },
  { id: "healing", name: "Healing & Cultural Memory", pillar: "R", tags: ["healing", "archives", "ancestral data"], affirmation: "I carry my ancestors forward." },
  // E
  { id: "love", name: "Love", pillar: "E", tags: ["love", "loving", "care"], affirmation: "I am love in motion." },
  { id: "community", name: "Community & Togetherness", pillar: "E", tags: ["community", "togetherness", "teamwork", "a sense of community", "broader-level community"], affirmation: "I belong, and I make room for others to belong." },
  { id: "empathy", name: "Empathy & Compassion", pillar: "E", tags: ["empathy", "compassion", "kindness", "kindful", "helpful"], affirmation: "I lead with tenderness." },
  { id: "respect", name: "Respect & Acceptance", pillar: "E", tags: ["respect", "acceptance", "open-mindedness", "humility"], affirmation: "I honor every way of being." },
  { id: "equity", name: "Equity & Representation", pillar: "E", tags: ["equity", "equality", "equal", "empower", "representation", "inclusiveness", "women", "everyone deserves a home"], affirmation: "I design futures with a seat for everyone." },
  { id: "family", name: "Family & Friendship", pillar: "E", tags: ["family", "friends", "friendship", "trust"], affirmation: "I am rooted in the people I love." },
  { id: "peace", name: "Peace", pillar: "E", tags: ["peace", "world peace", "still water"], affirmation: "I am still water." },
  // A
  { id: "imagination", name: "Imagination & Creativity", pillar: "A", tags: ["imagination", "creativity", "creative"], affirmation: "I am a builder of new worlds." },
  { id: "curiosity", name: "Curiosity & Learning", pillar: "A", tags: ["curiosity", "learning"], affirmation: "I follow my wonder." },
  { id: "hope", name: "Hope & Change", pillar: "A", tags: ["hope", "change", "revolution"], affirmation: "I dream despite the dark." },
  { id: "joy", name: "Joy & Happiness", pillar: "A", tags: ["happiness", "joy", "music"], affirmation: "My joy is a form of resistance." },
  { id: "courage", name: "Courage & Confidence", pillar: "A", tags: ["courage", "confidence", "belief", "determination", "dedication", "pride"], affirmation: "I am brave enough to imagine." },
  // M
  { id: "abundance", name: "Abundance", pillar: "M", tags: ["abundance", "no poverty"], affirmation: "I am cultivating a planet of abundance." },
  { id: "nourishment", name: "Shared Nourishment", pillar: "M", tags: ["food", "community farming", "community gatherings", "bartering"], affirmation: "There is enough when we share." },
  { id: "health", name: "Health & Wellbeing", pillar: "M", tags: ["health"], affirmation: "My wellbeing is wealth." },
  { id: "freedom", name: "Freedom", pillar: "M", tags: ["freedom"], affirmation: "I am free to become." },
  // Spirit & Meaning
  { id: "faith", name: "Faith", pillar: "S", tags: ["god", "jesus", "religion", "faith", "beliefs"], affirmation: "I walk with faith." },
  { id: "gratitude", name: "Gratitude", pillar: "S", tags: ["grateful", "thankful"], affirmation: "I receive each day as a gift." },
  { id: "reverence", name: "Reverence", pillar: "S", tags: ["reality is my illusion", "the universe is a hologram"], affirmation: "I stand in awe of the mystery." },
];

// Shown as "futures to redesign", never judged.
export const TENSIONS = [
  { id: "data-worship", name: "Data-Worship", pillar: "R" as PillarId, question: "What would it look like if data served people instead of the reverse?" },
  { id: "interplanetary", name: "Interplanetary Expansion", pillar: "D" as PillarId, question: "What if we loved this planet as much as the next one?" },
  { id: "growth", name: "Economic Growth", pillar: "M" as PillarId, question: "Growth, or enoughness? What does a thriving economy measure?" },
  { id: "ai-does-all", name: "AI Does All the Work", pillar: "A" as PillarId, question: "If machines do the work, what gives life meaning?" },
];

export const valueById = (id: string) => VALUES.find((v) => v.id === id);

/** Map a participant's raw tag to a cluster id, if it fits one. */
export function normalizeTag(raw: string): string | undefined {
  const t = raw.trim().toLowerCase();
  return VALUES.find((v) => v.tags.includes(t))?.id;
}
