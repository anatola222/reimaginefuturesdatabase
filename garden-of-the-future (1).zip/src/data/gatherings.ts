// Real gathering data. Counts are copied from the live poll results.
export interface Poll { q: string; answered: number; options: [string, number][]; valueIds?: (string | null)[] }
export interface Gathering {
  id: string; label: string; place: string; dates: string; year: number; ages: string;
  who: string[]; participants: number; polls: Poll[];
  words: { q: string; answered: number; total: number; top: [string, number][]; rest: string[] };
}

export const GATHERINGS: Gathering[] = [
  {
    id: "atl-2026",
    label: "D.R.E.A.M. Futures Lab",
    place: "Atlanta, Georgia", // kept for records, not shown on the site
    dates: "October 9–11, 2026",
    year: 2026,
    ages: "15–84",
    who: ["Students", "Artists", "Creators", "Entrepreneurs", "Tech workers", "AI prompt engineers", "Consultants"],
    participants: 15,
    polls: [
      { q: "What values rule your future world?", answered: 13,
        options: [["Community", 5], ["Harmony with nature", 5], ["Abundance", 2], ["Interplanetary Expansion", 1], ["Data-Worship", 0]],
        valueIds: ["community", "harmony", "abundance", null, null] },
      { q: "Where does your world take place?", answered: 11,
        options: [["Parallel Dimension", 4], ["Sky Islands", 3], ["Bioluminescent Forest", 3], ["Vast Desert", 1], ["Underwater City", 0]] },
      { q: "What do children aspire to be when they grow up in your imagined world?", answered: 13,
        options: [["Space Habitat Designer", 4], ["Quantum Reality Architect", 4], ["Nothing (AI does all the work)", 3], ["Data Archivist", 1], ["3D Printed Food Farmer", 1]] },
    ],
    words: {
      q: "What new technology is shaping your imagined future?", answered: 10, total: 27,
      top: [["ai", 2]],
      rest: ["3d", "augmented reality", "body relaxation", "community", "enhancements", "ethical ai generation", "filtration plants",
        "full sensory stimulation", "fun", "heart of creation", "hydro power", "hyper-warp tech", "integrity", "joy", "motion capture",
        "mutual aid", "plant", "prosthetics", "quantum physics", "rain water collection", "robotics", "spirituality", "sun blotting",
        "technology", "unconditional love"],
    },
  },
];

/** Value counts from gathering polls (aggregate answers, not tied to individual visions). */
export function pollValueCounts() {
  const out: Record<string, number> = {};
  for (const g of GATHERINGS) for (const p of g.polls) p.valueIds?.forEach((id, i) => { if (id) out[id] = (out[id] ?? 0) + p.options[i][1]; });
  return out;
}

/** Real counts for tension signals, keyed by tension id. */
export const TENSION_COUNTS: Record<string, { n: number; of: number; where: string }> = {
  "interplanetary": { n: 1, of: 13, where: "2026" },
  "data-worship": { n: 0, of: 13, where: "2026" },
  "ai-does-all": { n: 3, of: 13, where: "2026" },
};
