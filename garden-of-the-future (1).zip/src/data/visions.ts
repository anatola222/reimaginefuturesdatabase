// Visions: real participant responses.
// Only cohort-level fields are stored; no names or personal identifiers.
export type Cohort = "youth" | "adult" | "mixed";

export interface Vision {
  id: string;
  workshop: string;
  year: number;
  cohort: Cohort;
  setting: string;
  aspiration: string;
  technology: string;
  description: string;
  stated: string[]; // raw Values tags as participants wrote them
  inferred: string[]; // cluster ids suggested by AI from Description / Day in the Life
  hidden?: boolean; // meme / playful entries, hidden by moderation
  tension?: string; // tension signal id
  gathering?: string;
}

export const VISIONS: Vision[] = [];

// Atlanta 2026, answers to: "A spaceship lands on your new world. What will visitors see?"
// Exact words. Values are AI-inferred from the text and need curator approval.
type A = [string, string, string[], boolean?];
const atl: A[] = [
  ["Green little men", "Unspecified", [], true],
  ["Evergreen lands", "Forest", ["harmony"]],
  ["As they land they see a prosperous civilization with cities that do not hinder nature. They notice everyone seems connected and as if they all are connected to one another but also of a higher freq", "City", ["harmony", "interconnection", "abundance", "reverence"]],
  ["They will see nature and clean architecture Fall weather at 75%", "City", ["harmony", "sustainability"]],
  ["Visitors feel welcomed, constant soul music playing, slow paced and life valued environment", "Unspecified", ["joy", "peace", "respect"]],
  ["The visitors will see desolation. The people are meek, and the terrain is grand. The sand shifts like waves, and so big civilizations are impossible. The people are small in stature, very agile.", "Desert", ["harmony", "respect"]],
  ["Visitors land on the beach and they see blue water, smell fresh fruit and the buildings are built o brick and wood. The people are sun kissed and live in the present in community.", "Coast", ["community", "nourishment", "peace"]],
  ["The people are hybrids from different species, all evolved to live in this dimension called the “Sea Of Space” where everything below is water and everything above is purple galactic sky", "Parallel dimension", ["imagination", "respect"]],
  ["Multicultural people communing with one another with dance, food, praise, education and celebration of each other’s lives.", "Unspecified", ["community", "respect", "joy", "faith", "curiosity"]],
  ["Tall skyscrapers covered in flora, with clean air and recyclable energy. Orange skies, pink and purple swirls with a deep burnt orange sun, African architecture and renewable energy. 3 moons.", "City", ["sustainability", "harmony", "healing"]],
];
VISIONS.push(...atl.map(([d, setting, inf, hide], i): Vision => ({
  id: `atl${i + 1}`, workshop: "D.R.E.A.M. Futures Lab", year: 2026, cohort: "mixed", setting,
  aspiration: "Unspecified", technology: "Unspecified", description: d, stated: [], inferred: inf,
  hidden: !!hide, gathering: "atl-2026",
})));
