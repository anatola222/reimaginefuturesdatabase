import type { PillarId } from "./pillars";

// "Your D.R.E.A.M. Field Guide" by Anatola Araba. Text as supplied.
// Lines with unfinished placeholders ([xx%], [to complete], [to add]) are left out until the figures are confirmed.
export interface GuideBox { n: number; title: string; lines: string[] }
export interface GuidePillar { id: PillarId; meaning: string; boxes: GuideBox[]; tryThis?: string[] }

export const GUIDE_INTRO = {
  title: "Your D.R.E.A.M. Field Guide",
  sub: "What these futures mean for you, and how you can start building them today",
  body: "Every future you see in this database began with someone like you, imagining out loud. Look to the past to move forward, but don’t let the past become a prescription for the future. You get to write what comes next.",
};

export const GUIDE: GuidePillar[] = [
  {
    id: "D",
    meaning: "You are not separate from nature, and neither is anything you build. Every design, classroom, and city you touch can learn from the living world.",
    boxes: [
      { n: 1, title: "Nature is the foundation", lines: [
        "When I asked a humanoid robot (Sophia) to imagine the future of education, she imagined nature and technology combined.",
        "Nature is our oldest technology. Notice how almost every future you imagine includes it.",
        "You can design with living systems, where the built world and the natural world become one.",
        "Vision: Coral walls grown in tanks that restore reefs and eat plastic (CIPC UK / Ny’Mara)",
        "Vision: Treehouse communities (LumaRoot)",
      ] },
      { n: 2, title: "Plant intelligence", lines: [
        "We talk a lot about artificial intelligence. Start noticing natural intelligence too.",
        "I learned the power of plant intelligence while growing mycelium as a professor at Pratt Institute.",
        "The Venus flytrap closes only after a double touch. That’s built-in “if-then” logic that saves energy.",
        "Indigenous peoples have always known the plants: herbalism, and plants that connect us to other realms.",
      ] },
      { n: 3, title: "Nature in architecture", lines: [
        "Explore biomorphic design and eco-architecture, which treat nature as a blueprint, not a backdrop.",
        "Read: Jean-Olivier Rende, Terrestrial Architecture. He argues nature is a technology (techne, “to know how”) and envisions cities that breathe and metabolize like forests.",
        "Explore: Future of Cities and Geoship, two regenerative urban models.",
      ] },
      { n: 4, title: "Cities as living organisms", lines: [
        "Futurist, urban planner, and RISD professor Lafayette Cruise taught me that cities, like bee hives, are living organisms. Ask yourself: why question a city designed to suit our nature?",
        "Explore: Tony Cho’s Future of Cities, a 17-acre living lab in Little Haiti, Miami. It’s built on regeneration over sustainability, renewable energy, urban agriculture, and circular economies.",
        "Explore: ICON’s 3D-printed homes (I visited in Austin while speaking at SXSW EDU and NASA, and featured them in one of my films).",
        "Explore: Alfredo Celzar Caro, who prints structures from raw earth.",
        "Learn from: Buckminster Fuller, who argued domes are the most sustainable shape. That’s why domes appear in R3imagine Immersive and in the capitol building of Afro Algorithms.",
        "Explore: Geoship’s bioceramic domes, inspired by bone and shell. They resist fire, mold, and extreme weather, and I’m an early investor.",
        "Connect to: UN SDG 11, Sustainable Cities & Communities. Then dream past it, toward cities that actively heal.",
      ] },
      { n: 5, title: "Native African & Indigenous cues", lines: [
        "Ancient African and Indigenous communities built circular, domed homes of earth, clay, and thatch. The circle meant wholeness, equality, and continuity.",
        "What looks futuristic is often ancestral memory in modern materials.",
        "Growing up on New York City’s grid, I once asked friends, “Why aren’t the streets curved like the rivers?” If you’ve ever asked questions like that, you might be from the future too.",
      ] },
      { n: 6, title: "Classrooms in nature", lines: [
        "Imagine Sophia’s outdoor classrooms: math through leaves, art through biomimicry, science through soil and water.",
        "Imagine lunchrooms where composting replaces waste and vertical farms replace vending machines.",
      ] },
      { n: 7, title: "Community gardens as care", lines: [
        "In neighborhoods of color shaped by redlining and food deserts, gardens and food pantries are survival and renewal.",
        "A garden is resistance, a micro-infrastructure of care.",
        "If you’re a designer: use materials that age beautifully, design for natural light and airflow, prototype with soil or recycled fibers, and compost and co-design with community.",
      ] },
    ],
    tryThis: ["Walk in nature", "Talk to a tree (you might become friends)", "Bring a plant or garden home", "Try a meditation imagining cities in nature", "Teach your children or students about plant intelligence", "Grow something you can eat", "Draw or generate a nature-based city", "Learn about herbs"],
  },
  {
    id: "R",
    meaning: "Technology reflects whoever builds it. When you build, use, and question tech through your own values, you help make tech that heals, not harms.",
    boxes: [
      { n: 1, title: "Why your values matter in tech", lines: [
        "If tech isn’t built on values, it will keep being led by the values of a few billionaires.",
        "We’ve always compared the brain to the most advanced tech of the time: the aqueduct (a Matrix reference), then the computer, now AI.",
        "Even the Akashic records get described as a supercomputer.",
        "How you relate to technology shapes how you see yourself.",
      ] },
      { n: 2, title: "UbuntuTech", lines: [
        "Learn from: Nanjira Sambuli, who introduced #UbuntuTech at TED 2025: Humanity, Reimagined.",
        "It’s AI guided by empathy, reciprocity, and community: “I am because we are.”",
      ] },
      { n: 3, title: "Ancestral technology", lines: [
        "Watch: AI: African Intelligence, on training algorithms with ancestral knowledge.",
        "A plant-medicine shaman describes ayahuasca as ancestral technology, more powerful than the internet.",
        "Writing was once a technology too, one that needs no dangerous rare earth metals.",
      ] },
      { n: 4, title: "Know the cost of your devices", lines: [
        "Rare earth metals in gaming devices are harming communities in the Congo.",
        "Lithium in “eco-friendly” batteries harms local people and environments.",
      ] },
      { n: 5, title: "Technology reflects power", lines: [
        "Read: Lizzie O’Shea, Future Histories. To design forward, look backward.",
        "Innovation has often automated inequality. The next revolution can serve the working class and the global majority, and you can help.",
      ] },
      { n: 6, title: "Values-based AI", lines: [
        "Explore: Mind Heart AI.",
        "Imagine AI trained on empathy as much as data, and networks that heal the digital divide.",
      ] },
      { n: 7, title: "Technology as a bridge between past and future", lines: [
        "Vision: AI oracles and holographic campfires",
        "Vision: Buildings embedded in the landscape, “Singapore style” (CalArts)",
        "Vision: Tech that brings us closer to nature (Genesis Gathering)",
        "Vision: Technology that stays “hidden and low-key” (Community Villages)",
        "Learn from: Phnam Badgley, who argues space should be designed for comfort: hygiene, makeup, Black hair in space.",
        "Explore: solarpunk and human-centered design.",
        "Read: Octavia Butler, who said that to predict the future you must first understand the past’s version of it.",
      ] },
      { n: 8, title: "Archiving cultures through code", lines: [
        "Explore: Abran, Create Labs, which builds AI that preserves Indigenous languages and storytelling. Think “machine remembering.”",
        "Explore: Masakhane, “For Africans, by Africans.”",
        "Look into AI being trained in Swahili, Yoruba, Amharic, Twi, and Zulu.",
      ] },
      { n: 9, title: "Listening to the Earth", lines: [
        "AI is beginning to help us decode whale songs, elephant calls, and tree networks.",
        "As Tony Cho puts it, tech shouldn’t make cities smart. It should make them wise.",
      ] },
      { n: 10, title: "Environmental harm and positive uses", lines: [
        "Training one large language model is estimated to emit about as much as five American cars over their lifetimes. Video generation uses even more.",
        "Try: the AI Energy Calculator to see the footprint of your AI images and video.",
        "AI can also design climate-responsive homes, map soil health, restore coral reefs, and track migration.",
      ] },
      { n: 11, title: "Your role", lines: [
        "Artist: reconnect people. Technologist: code with empathy. Student: ask how your school could learn with nature. Storyteller: archive the present with care.",
        "Anyone: text someone you miss, unfollow a distraction, and learn who your tools serve.",
      ] },
    ],
    tryThis: ["Meditate on living in harmony with nature and technology", "Use AI to archive your stories", "Try R3imagineGPT", "Bring our ethical AI curriculum to your organization", "Support transparent, open data sharing"],
  },
  {
    id: "E",
    meaning: "Belonging is as essential as food, water, and oxygen. Every time you choose connection, you’re building the future’s real infrastructure.",
    boxes: [
      { n: 1, title: "Start here", lines: ["An autistic child’s last prayer to humanity was for us to love each other."] },
      { n: 2, title: "Love is the future young people want", lines: ["At SAAACAM, 300+ middle and high school students named the values that should guide the future. Their most common answer was love."] },
      { n: 3, title: "Imagine a society built on love", lines: [
        "Melissa (MA, USA) imagined joy as currency and education everywhere.",
        "Gilda Gold asked: what if you treated everyone like friends and family?",
      ] },
      { n: 4, title: "Love is infrastructure", lines: ["Without love, cities and technologies become hollow."] },
      { n: 5, title: "Community as home", lines: [
        "Vision: Organic and geometric structures in balance (CalArts)",
        "Vision: Community, not family, as the “unit”",
        "Vision: Elders whose wisdom guides the community",
        "Vision: Everyone taking part in governance and conflict resolution",
        "Think communal kitchens.",
        "“You can build a city, but without the community, infrastructure is empty.”",
      ] },
      { n: 6, title: "Connection and AI", lines: [
        "AI companions and AI animals can offer connection to people who would otherwise go without.",
        "Learn the neuroscience of oxytocin, and be aware of the “false oxytocin” AI can create.",
      ] },
      { n: 7, title: "Love as a design principle", lines: [
        "Imagine algorithms designed to cultivate belonging instead of capturing attention, trained on “the data of kindness.”",
        "Like forests sharing nutrients through their roots, systems can distribute care.",
      ] },
      { n: 8, title: "Micro-acts of belonging", lines: [
        "At work: listen instead of waiting to speak. In class: invite someone new to sit with you. In creative practice: design with people, not for them.",
        "Belonging scales. One gesture ripples outward.",
      ] },
    ],
    tryThis: ["Next time you feel road rage, ask “what if this were someone I loved?”", "Message a friend: “Hey! I was just thinking about you. Sending love!”", "Meditate on being held in a bubble of unconditional love", "Listen instead of waiting to speak", "Invite someone new to sit with you", "Design with people, not for them", "Cook a meal and share it with someone outside your usual circle", "Ask an elder what wisdom they would pass on to the future"],
  },
  {
    id: "A",
    meaning: "Beauty is not a luxury, it’s a language. Your creativity, play, and wonder are civic contributions to the future.",
    boxes: [
      { n: 1, title: "Futures full of play, creativity, and wonder", lines: ["Colorful, playful worlds, not cold metal cities."] },
      { n: 2, title: "Vibrant, biomorphic architecture", lines: ["“No straight lines… languages are song” (Genesis Gathering).", "Organic and geometric structures in balance."] },
      { n: 3, title: "Color is joy and belonging", lines: ["Purples, pastels, iridescence, bioluminescence.", "XR Women imagined purples, oranges, waterfalls, and “love and kindness in the air.”"] },
      { n: 4, title: "Beauty that nourishes (XR Women)", lines: ["Quirky, happy people creating ways to feed and educate everyone.", "Moon gardening, edible habitats, and edible corridors through cities."] },
      { n: 5, title: "Community is an aesthetic", lines: ["Arts communities, dancing, living together “like playing in an orchestra.”"] },
      { n: 6, title: "Feeling over form", lines: ["“I don’t know that I care so much about what it looks like, but that’s what I want it to feel like.”"] },
      { n: 7, title: "Get inspired by", lines: [
        "Explore: Mexico City: Frida Kahlo blue walls, pink murals, flower markets.",
        "Explore: Michael Jackson’s Neverland: joy as radical architecture.",
        "Explore: Institute of Play: play activates creativity, empathy, and problem-solving.",
      ] },
      { n: 8, title: "Imagine", lines: ["Bus stops that double as art, parks that play music, libraries that glow like coral, solar-thread fashion, interfaces that feel alive."] },
      { n: 9, title: "The science of play", lines: [
        "Play lights up your prefrontal cortex and the dopamine and oxytocin pathways of safety and flow.",
        "What if cities rewarded collaboration, workplaces ran on curiosity, and schools gamified growth instead of grades?",
      ] },
      { n: 10, title: "We remember forward", lines: ["Design with colors, fabrics, symbols, and geometries that echo your roots."] },
    ],
    tryThis: ["Add one act of beauty to your day", "Paint your workspace", "Plant something that blooms", "Wear the outfit that makes you feel like your higher self", "Curate your digital spaces like galleries for joy", "Build with color, teach with story, code with rhythm"],
  },
  {
    id: "M",
    meaning: "Wealth isn’t what you keep, it’s what you circulate. Your creativity, care, and collaboration are currencies that never run out.",
    boxes: [
      { n: 1, title: "A new way to see wealth", lines: ["Name the old system: ECPC (European Christian patriarchal capitalism).", "Imagination is capital, knowledge is renewable, and cooperation compounds."] },
      { n: 2, title: "Matriarchy and yin-yangiarchy", lines: [
        "I favor matriarchy.",
        "I also include yin-yangiarchy: a balance of male and female energy.",
      ] },
      { n: 3, title: "Ask the question", lines: ["What if growth isn’t the point anymore?"] },
      { n: 4, title: "Community visions to explore", lines: [
        "Vision: “There is no such thing as work—we all contribute as we can.”",
        "Vision: Most possessions are communal.",
        "Vision: Communities trade food, art, and ideas along a string of forests and lakes.",
        "Vision: XR Women imagined people giving back after achieving their dreams.",
        "Vision: “The land is not sacrificed at the expense of constructing” (Tropical Lab).",
        "Vision: Coral walls that fund reef restoration, and green buildings full of trees.",
        "Vision: Being “content and fulfilled,” “no poverty,” and a welcoming meal.",
        "Vision: “Time is no longer a concept” (Aurava).",
        "Vision: Food towers, shared spaces for eating and talking, wise elders, self-built wooden huts, life “like playing in an orchestra.”",
      ] },
      { n: 5, title: "Robin Wall Kimmerer, The Serviceberry", lines: [
        "Read: Robin Wall Kimmerer, “The Serviceberry.”",
        "In a gift economy, value grows when it’s shared. She calls it the covenant of reciprocity.",
        "The serviceberry ripens all at once, so no one can hoard it.",
      ] },
      { n: 6, title: "The Next Economy MBA", lines: ["Explore: The Next Economy MBA, on regenerative enterprise that gives back more than it takes."] },
      { n: 7, title: "The economics of enough", lines: ["Enough is abundance."] },
      { n: 8, title: "Where you’ll find the next economy", lines: ["Gardens, co-ops, collectives, coral reefs, code repositories, dinner tables. It’s already here, in people who believe giving is the new wealth."] },
    ],
    tryThis: ["Write “money is love” on your checks", "Ask yourself, “Is this mutually beneficial for all parties?”", "Grow something and give it away to someone else", "Offer a gift with nothing expected in return", "Ask, “How can I help?”", "Ask for help"],
  },
];

export const KINDS = ["Read", "Explore", "Learn from", "Watch", "Connect to", "Try", "Vision"] as const;
export function splitKind(line: string): { kind?: string; text: string } {
  for (const k of KINDS) if (line.startsWith(`${k}: `)) return { kind: k === "Vision" ? "Community vision" : k, text: line.slice(k.length + 2) };
  return { text: line };
}
